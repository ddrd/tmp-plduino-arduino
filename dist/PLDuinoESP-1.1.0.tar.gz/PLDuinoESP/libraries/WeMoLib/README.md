# WeMoLib
Simple WeMoSwitch emulation library for ESP8266.
