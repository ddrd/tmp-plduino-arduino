# ESP8266WeMo
ESP8266 library to emulate WeMo switches
