#pragma once
#include "UPnPResponder.h"
#include "WeMoSwitchEmulator.h"
