// script-generated, extracted from espressif SDK's lwIP arch/cc.h
#define LWIP_NO_STDINT_H 1
typedef unsigned   char    u8_t;
typedef signed     char    s8_t;
typedef unsigned   short   u16_t;
typedef signed     short   s16_t;
typedef unsigned   long    u32_t;
typedef signed     long    s32_t;
typedef unsigned long   mem_ptr_t;
#define LWIP_ERR_T s32_t
