#pragma once

namespace PLDuinoGUI
{

	const int FONTSIZE		= 2;
	const int CHARWIDTH		= 6;
	const int CHARHEIGHT	= 7;
	const int RH			= CHARHEIGHT * FONTSIZE;
	const int CW			= CHARWIDTH * FONTSIZE;


} // namespace
