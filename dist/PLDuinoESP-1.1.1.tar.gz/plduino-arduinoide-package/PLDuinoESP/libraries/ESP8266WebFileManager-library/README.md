# ESP8266WebFileManager-library
Implements simple Web GUI for managing files on ESP-02's built-in storage.
